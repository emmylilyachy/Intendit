# IntendIt — Installation Guide

## What is this?
IntendIt is a personal intention reminder app that notifies you at exactly the time you choose.
All data is stored privately on your device. Nothing is ever sent to any server.

---

## How to install on your Android phone (FREE — no app store needed)

### Option 1 — GitHub Pages (Recommended, easiest)

1. Create a free account at https://github.com
2. Click "New repository" — name it `intendit` — set it to **Public**
3. Upload all files in this folder (index.html, manifest.json, sw.js, icon-192.png, icon-512.png)
4. Go to Settings → Pages → Source: select "main" branch → Save
5. Your app URL will be: https://YOUR-USERNAME.github.io/intendit
6. Open that URL in Chrome on your Android phone
7. Tap the three-dot menu → "Add to Home Screen"
8. Done — IntendIt is now installed on your phone like a native app!

### Option 2 — Use a free hosting service
Upload the files to any of these free static hosts:
- https://netlify.com (drag and drop the folder — instant)
- https://vercel.com
Then open the provided URL in Chrome and "Add to Home Screen."

---

## Why it must be hosted (not just opened as a file)
Service workers — the technology that enables background notifications and offline use —
require a proper web address (https://). A raw HTML file opened from your Downloads
folder cannot register a service worker. Hosting is free and takes under 5 minutes.

---

## Permissions
When you first open the app, tap the yellow banner to allow notifications.
This is the only permission the app requests. No location, no contacts, no camera.

---

## Your data
- All reminders are stored in your browser's local storage on your device only.
- No account is required. No data is transmitted anywhere.
- Clearing your browser data will erase your reminders.

---

## Support
Built with standard HTML, CSS, and JavaScript. No frameworks, no dependencies,
no ongoing costs. Works on any modern Android browser.
